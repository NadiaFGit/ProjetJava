package Taxation;

import java.util.ArrayList;
import java.util.Iterator;

import facture.Facture;


public class Liste {

	// Attributs
			protected ArrayList<Fiche> table;
			private   int taille = 0;
			private String identite="";
			
			// Constructeur : Initialise la taille de la table		
		public Liste() {
			this.table= new ArrayList<Fiche>(taille);
			table.ensureCapacity(1000);
			this.taille = taille;
			this.identite= identite;
			}

			// Mutateur : Ajoute une fiche
			public  boolean insertFiche( String date, String poste, double montant ){ 
				int nb = table.size(); 
				if ( nb >= taille ) return false;
				table.add(nb, new Fiche( date, poste, montant));
				System.out.printf("Insertion de [%s] � %d\n", poste, nb);
				return true;
			} // insert
			
			// Accesseurs
			public String getIdentite()  { return this.identite;  }
			
	
			
			// Mutateurs
			public void setIdentite(  String identite )  { this.identite  = identite;  }
			public int getTaille(){return table.size(); }
			
			
		/*	public void addTransaction( String date, String poste, double montant ) {
	          Iterator i =table.iterator();

				while (i.hasNext()) { table.add( new Fiche( date, poste, montant));}

			}*/
			
			public double SommeTotal(){
				
				int somme=0;
				for (int j = 0; j< table.size(); j++) {somme+=((Fiche) table.get(j)).getMontant();}
				return somme;
			}
				

			
			

		public void addTransaction (String date, String poste, double montant ){
				int nb= 0;
				while(nb<table.size()+1)
				table.add(nb,new Fiche(date,poste,montant));
				nb++;
			}
			
			
			/*public String toString() {
				String = "\n";		
				/*Object o;
				Iterator i =table.iterator();
				
				while (i.hasNext()) { resultat+=table.get(i).getFiche(); }*/
				
				/*for (int i = 0; i < table.size(); i++) { resultat +=table.get(i).getFiche();}
				
				return resultat;
			} // toString()*/
			
			
		
			public void getRapport(){
	         /*  Iterator i =table.iterator();
				
				while (i.hasNext()) { System.out.println(i.next()); 	
				System.out.printf("size :%s   ", 	getTaille());*/
				
		
				for (int j = 0; j< table.size(); j++) {((Fiche) table.get(j)).getFiche();}
			}
			}



