package Taxation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Fiche {

	// Constantes
			final private static double TPS = 0.05d;
			final private static double TVQ = 0.0975d;
			final private static double SANSTAXES = 1.14975d;

			// Attributs
			public static String date="2021-02-20";
			public static  String poste= "Auto";
			public static double montant;
			public static double tps;
			public static double tvq;
			public static double sommeTotal=0;
			
			

			// Constructeurs
			public Fiche( String date, String poste, double montant ) {
				setDate(date);
				setPoste(poste);
				setMontant(montant);
		
				
			} // Fiche

			// Accesseurs
					public String getDate()  { return this.date;  }
					public String getPoste() { return this.poste; }
					public double getMontant() { return this.montant;}
				
					
					// Mutateurs
					public void setDate(  String date )  { this.date  = date;}
					public void setPoste( String poste ) { this.poste = poste;}
					public void setMontant( double montant ) { this.montant = montant; }//
					
					public void setFiche(LocalDate date,String poste, double mnt )
					{DateTimeFormatter formatter_1= DateTimeFormatter.ofPattern("yyyy-mm-dd");
						this.date = date.format(formatter_1); 
						setPoste(poste);
						setMontant(montant);}
			
			/*public void getFiche(){
				*/
					
				public void getFiche() {	
				double mntTaxes= getMontant()/SANSTAXES ;
				double tps   = mntTaxes * TPS;
				double tvq   = mntTaxes * TVQ;
				
				System.out.printf(" %s   ", 	getDate());
				System.out.printf(" %s   ", 	getPoste());
				System.out.printf(" %10.2f   ", mntTaxes);
				System.out.printf("%10.2f   ", tps);
				System.out.printf("%10.2f   ", tvq);
				System.out.printf(" %10.2f   \n", getMontant());
				
			} // getFiche()*/
				
			
				

}
