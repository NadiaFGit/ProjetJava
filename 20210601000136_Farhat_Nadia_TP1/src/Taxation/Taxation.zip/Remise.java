package Taxation;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;


public class Remise {

	// Attributs
	
	public static int noTrim=0;
	public static String annee;
	private static int taille;
	private static int nbrangs;
	private static int compt1=0;
	private static int compt2=0;
	public static Liste revenus= new Liste();
	public static Liste depenses= new Liste();

	// Accesseurs
	public int  getNoTrim()  { return this.noTrim;  }
	public String getAnnee() { return this.annee; }
	public int getNbrangs() { return this.nbrangs; }
	
	// Mutateurs
	public void setNoTrim(  int noTrim)  { this.noTrim  = noTrim;  }
	public void setAnnee( String annee) { this.annee = annee; }
	public void setNbrangs1(int nbrangs) { this.nbrangs = nbrangs; }
	
	// Constructeurs
	public Remise( int nbrangs, int noTrim, String annee ) {
		
		this.setNoTrim(noTrim);
		this.setNbrangs1(nbrangs);
		this.setAnnee(annee);
	
	} // Remise
	
	// M�thodes addRevenu ============================================================================
	public void addRevenus(String date, String poste, double mnt) {
	
		
	Iterator i = ((List) revenus).iterator();
		    // Print the first item
		    System.out.println(i.next());
		
		
		
		while (i.hasNext()) {revenus.addTransaction( date, poste, mnt );}
		compt1++;	
	nbrangs =compt1;
	
	} // addRevenu()
	
	// M�thodes addRevenu ============================================================================
	public void addDepenses(String date, String poste, double mnt) {
	
		Iterator i = ((List) depenses).iterator();

		while (i.hasNext()) {depenses.addTransaction( date, poste, mnt );
		compt2++;
		nbrangs =compt1;}
	}
	public void getRapport(){
		Iterator i = ((List) revenus).iterator();
			while (i.hasNext()) 
			{ 
				System.out.println(i.next());
			}
			
			Iterator j = ((List) depenses).iterator();
			
			while (j.hasNext()) { System.out.println(j.next()); 	}

			

		}


}
